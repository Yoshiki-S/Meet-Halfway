require 'simplecov'
SimpleCov.start 'rails' do
  skip '/bin/'
  skip '/db/'
  skip '/spec/'
  skip '/config/'
end

# -*- encoding: utf-8 -*-
require 'bundler/setup' # 1. Gemの読み込み環境を整える
require 'simplecov'     # 2. ここで初めて SimpleCov を読み込む
require 'webmock/rspec' # 3. WebMock を読み込む

SimpleCov.start 'rails' do
  skip '/bin/'
  skip '/db/'
  skip '/spec/'
  skip '/config/'
end

require 'spec_helper'
ENV['RAILS_ENV'] ||= 'test'
require_relative '../config/environment'
# Prevent database truncation if the environment is production
abort("The Rails environment is running in production mode!") if Rails.env.production?
require 'rspec/rails'
# Add additional requires below this line. Rails is not loaded until this point!

# Checks for pending migrations and applies them before tests are run.
# If you are not using ActiveRecord, you can remove these lines.
begin
  ActiveRecord::Migration.maintain_test_schema!
rescue ActiveRecord::PendingMigrationError => e
  abort e.to_s.strip
end

RSpec.configure do |config|
  # Remove this line if you're not using ActiveRecord or ActiveRecord fixtures
  config.fixture_paths = [
    Rails.root.join('spec/fixtures')
  ]

  # If you're not using ActiveRecord, or you'd prefer not to run each of your
  # examples within a transaction, remove the following line or assign false
  # instead of true.
  config.use_transactional_fixtures = true

  # RSpec Rails can automatically mix in different behaviours to your tests
  # based on their file location...
  config.infer_spec_type_from_file_location!

  # Filter lines from Rails gems in backtraces.
  config.filter_rails_from_backtrace!

  # ★ここに FactoryBot のメソッドを省略して書けるようにする設定を追加します
  config.include FactoryBot::Syntax::Methods

  #config.include Devise::Test::IntegrationHelpers, type: :request
end